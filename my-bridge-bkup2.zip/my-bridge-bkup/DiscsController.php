<?php
/**
 * @name        FilesController.php
 * @copyright   Evon Technologies Pvt. Ltd. 2015
 * @version     2.5.x
 *
 */

App::uses('AppController', 'Controller');

class DiscsController extends AppController {
    public $helpers = array('Html', 'Form', 'Session');
    public $session = array('Session');



    public $uses = array('DiscPaymentDetail','User','UploadedFile','createTeam','Profile','Invitation','ShareDocument','DiscTeamMember','DiscTeam','Mydiscfile','Country','Post', 'BusinessDetail', 'UserExperience');

    public function beforeFilter()
    {
        parent::beforeFilter();
        $logged_user = $this->Auth->user('id');
        $this->set('logged_user',$logged_user);

$loggedUserData = $this->Profile->find('first',array('conditions'=>array('Profile.user_id'=> $logged_user)));
$lastName = $loggedUserData['Profile']['last_name'][0];
$loggedUserName = $loggedUserData['Profile']['first_name'].' '.$lastName.'.';
$loggedUserImage = $loggedUserData['Profile']['image_url'];

if($loggedUserImage == ''){
  $loggedUserImage = 'pro-top.png';
}
$this->set('loggedUserImage',$loggedUserImage);
         define("LOGGEDUSERNAME",$loggedUserName);
          define("LOGGEDUSERID",$logged_user);


        $this->Auth->allow('getfiles','share','sharedfile','removeInvite','leaveTeam','token','changeAccept','TrashFile','inviteMembers','getTeams','deleteteam','teamdetail','teamsetting','createTeam','getrestorefile','makedir','getfilestrash','permanentDelete','downloadfiles','zipfile','copypopup','movepopup','makedir','movedir','renamee','copydir','showfilesrecursive');
        define("USERID",$this->Auth->user('id'));

        // GET ALL TEAMS 
        $get_teams = $this->DiscTeam->find('all', array(
        'conditions' => array('DiscTeam.created_by' => USERID)));

        $this->set('teams',$get_teams );
// ================= space management for login user ============//
         $account_updated= $this->DiscPaymentDetail
          ->find('count', array('conditions' => array('DiscPaymentDetail.user_id = '=> USERID)));

        if($account_updated == '0'){
        $limit = 10*1000*1000; // 10MB
        }else{  $limit = 20*1000*1000; // 20MB
        }
        $this->set('account_updated',$account_updated);


        function folderSize($dir){
$count_size = 0;
$count = 0;
$dir_array = scandir($dir);
  foreach($dir_array as $key=>$filename){
    if($filename!=".." && $filename!="."){
       if(is_dir($dir."/".$filename)){
          $new_foldersize = foldersize($dir."/".$filename);
          $count_size = $count_size+ $new_foldersize;
        }else if(is_file($dir."/".$filename)){
          $count_size = $count_size + filesize($dir."/".$filename);
          $count++;
        }
   }
 }
return $count_size;
}
function sizeFormat($bytes){ 
    $kb = 1000;
    $mb = $kb * 1000;
    $gb = $mb * 1000;
    $tb = $gb * 1000;

    if (($bytes >= 0) && ($bytes < $kb)) {
    return $bytes . ' B';

    } elseif (($bytes >= $kb) && ($bytes < $mb)) {
    return round(floatval($bytes / $kb),2) . ' KB';

    } elseif (($bytes >= $mb) && ($bytes < $gb)) {
    return round(floatval($bytes / $mb),2) . ' MB';

    } elseif (($bytes >= $gb) && ($bytes < $tb)) {
    return floatval($bytes / $gb) . ' GB';

    } elseif ($bytes >= $tb) {
    return floatval($bytes / $tb) . ' TB';
    } else {
    return $bytes . ' B';
    }
}
         
$dir = DOCUMENT_ROOT_DISC.USERID;
$size = folderSize ( $dir );
   
    
    $perc_used = ($size/$limit)*100;
    //echo '</br>--per used'.$perc_used.'--'; 
    $size_show = sizeFormat($size);
    //echo '</br>'.$size_show; 
    //$disc_space_details = array('limit' => sizeFormat($limit),'used_disk');
   $disc_space_details['limit'] = sizeFormat($limit);
   $disc_space_details['limit_byte'] = $limit;
    $disc_space_details['used_disk'] = $size_show;
    $disc_space_details['used_disk_byte'] = $size;
    $disc_space_details['perc_used'] = $perc_used;
   // print_r($disc_space_details);die;
    $this->set('disc_space_details',$disc_space_details);

          // =============== end of disc management ===========
        // GET all members
        $get_joined_teams = $this->DiscTeamMember->find('all', array(
        'conditions' => array('DiscTeamMember.member_id' => USERID,'DiscTeamMember.is_accepted' => 1,'DiscTeamMember.is_owner' => 0 )));
      //  if($get_joined_teams[0]['DiscTeamMember']['is_owner'] == 0){
        $this->set('get_joined_teams',$get_joined_teams );
        //  } 


//  share disk data

        $loginUserId=USERID; 
    $permissionData=$this->ShareDocument->find('all', array('conditions' => array('ShareDocument.share_with_users_id  '=> $loginUserId)));
//echo "<pre>"; print_r($permissionData);die;
   $nameIdArr=array();
    foreach($permissionData as $key=>$permission){
      
        if($key == 0){
          $nameIdArr[]=$permission['ShareDocument']['user_id'];
          $permission['ShareDocument']['first_name']=$permission['Profile']['first_name'];
          $permission['ShareDocument']['last_name']=$permission['Profile']['last_name'];
          $permission['ShareDocument']['image_url']=$permission['Profile']['image_url'];
          $PermissionUserArr[]=$permission['ShareDocument'];
        }
        if(!in_array($permission['ShareDocument']['user_id'],$nameIdArr)) {

        $permission['ShareDocument']['first_name']=$permission['Profile']['first_name'];
        $permission['ShareDocument']['last_name']=$permission['Profile']['last_name'];
        $permission['ShareDocument']['image_url']=$permission['Profile']['image_url'];
        $PermissionUserArr[]=$permission['ShareDocument'];
        $nameIdArr[]=$permission['ShareDocument']['user_id'];
      }
    }
  //  print_r($PermissionUserArr); die('--');
    $this->set('PermissionUserArr',$PermissionUserArr);


// ========

//  share by me

       $loginUserId=USERID; 
    $permissionsData=$this->ShareDocument->find('all', array('conditions' => array('ShareDocument.user_id  '=> $loginUserId)));
//echo "<pre>"; print_r($permissionsData);die;
   $nameIdArr=array();
    foreach($permissionsData as $key=>$permission){
      
        if($key == 0){
          $nameIdArr[]=$permission['ShareDocument']['user_id'];
          $permission['ShareDocument']['first_name']=$permission['User']['first_name'];
          $permission['ShareDocument']['last_name']=$permission['User']['last_name'];
          $permission['ShareDocument']['image_url']=$permission['User']['image_url'];
          $PermissionsUserArr[]=$permission['ShareDocument'];
        }
        if(!in_array($permission['ShareDocument']['user_id'],$nameIdArr)) {

        $permission['ShareDocument']['first_name']=$permission['User']['first_name'];
        $permission['ShareDocument']['last_name']=$permission['User']['last_name'];
        $permission['ShareDocument']['image_url']=$permission['User']['image_url'];
        $PermissionsUserArr[]=$permission['ShareDocument'];
        $nameIdArr[]=$permission['ShareDocument']['user_id'];
      }
    }
   // echo "<pre>" ; print_r($PermissionsUserArr); die('--');
    $this->set('PermissionUsers',$PermissionsUserArr);


// ========

     // print_r($get_joined_teams); die;
     // echo $this->Auth->user('id'); die('---');   
    }

    public function teams(){
    $q = $_REQUEST[q];
     // print_r($_REQUEST); die;
    $DiscTeamdata=$this->DiscTeam->find('all', array('conditions' => array('DiscTeam.name LIKE '=> '%'.$q.'%'),
       'fields' => array('DiscTeam.id','DiscTeam.name')));
       // echo "<pre>"; print_r( $DiscTeamdata); die; 
        foreach($DiscTeamdata as $DiscTeam){
         //echo "<pre>"; print_r($user['User']);
       $ids=($DiscTeam['DiscTeam']['id']);
          $newUserArr[]=array("id"=>$DiscTeam['DiscTeam']['id'],"name"=>$DiscTeam['DiscTeam']['name']);
        }
       // echo "<pre>"; print_r( $newUserArr); die;
       echo $encodedData= json_encode($newUserArr);
      
    die;
   }


    public function team($id=null) {
      if($id){
     // echo $id; die('--');
      //$team_detail = $this->DiscTeam->find($id);
       $team_detail = $this->DiscTeam->find('first', array(
        'conditions' => array('DiscTeam.id' => $id)));
       $this->set('team_detail',$team_detail);
     // print_r($team_detail); die('--');
      }
        ini_set('memory_limit', '512M');
        $this->layout='profile_page';

        // $user_id = $this->Auth->user('id');
        $this->set('team_id', $id);
        $this->set('is_team_page', '1');
      }


  //================= leave Team ===========================================
public function leaveTeam($id=null){

     if($id){
      $logged_user = $this->Auth->user('id');
     
       $mem_team_id = $this->DiscTeamMember->find('first', array(
        'conditions' => array('DiscTeamMember.disc_team_id' => $id,'DiscTeamMember.member_id'=> $logged_user)));
    
      $mem_id = $mem_team_id['DiscTeamMember']['id'];

             
     $this->DiscTeamMember->delete($mem_id);
       $this->redirect('/discs/files/');


      }

}

// ===================================================================
  // ===================== invite members =============================================

      public function inviteMembers($team_id=null){
        $this->layout='profile_page';
        if($team_id){

            //  ---------- GET TEAM DETAIL  --------------------
        $team_data = $this->DiscTeam->find('first', array(
        'conditions' => array('DiscTeam.id' => $team_id)));
        $this->set('team_data',$team_data);

          if(!empty($_REQUEST['invite_user'])){

              $selectedIds=$_REQUEST['invite_user'];
              $selectedTeamIds=$_REQUEST['teamId'];
              $idsArr=explode(",",$selectedIds);
              $count=count($idsArr); 
             for($i=0;$i<$count; $i++){
              //print_r($ids);die;
                //$disc_member = array();
              $disc_member['DiscTeamMember']['member_id']= $idsArr[$i];
              $disc_member['DiscTeamMember']['disc_team_id']= $selectedTeamIds;
              $this->DiscTeamMember->create();
              $data=$this->DiscTeamMember->save($disc_member);
             

             $this->User->unbindModel(array('hasOne' => array('Profile')));
              $this->User->unbindModel(array('hasMany' => array('Post','UserSkill','UserContactAdvice','UserCertification','EducationDetail','UserMilestone','OtherDetail','BusinessDetail','JobDetail','SelectionDetail','InterviewDetail','UserExperience','BusinessConnection')));
              //  $userdata=$this->User->find('all',array('conditions'=>array('User.username LIKE '=> '%'.$q.'%'),array('fields'=>array('User.id','User.username')))); 
              $userdata=$this->User->find('all', array('conditions' => array('User.id  '=> $idsArr[$i]),
              'fields' => array('User.id','User.email')));

             // $userInfo=array();
               $this->Profile->unbindModel(array('hasMany' => array('UserExperience','UserSkill','UserCertification','EducationDetail','UserMilestone','OtherDetail','UserContactAdvice','BusinessDetail','Post')));

              $profileData=$this->Profile->find('all', array('conditions' => array('Profile.user_id  '=> $idsArr[$i]),
              'fields' => array('Profile.first_name','Profile.last_name','Profile.user_id')));
             if($userdata[0][User]['id'] == $profileData[0][Profile]['user_id']){
                 $userInfo['id']=$userdata[0][User]['id'];
                 $userInfo['userEmailid']=$userdata[0][User]['email'];
                 $userInfo['receiverName']=$profileData[0][Profile]['first_name']." ".$profileData[0][Profile]['last_name'];
             }




$mail             = new PHPMailer();

$body             = "<h1>Team Invitation</h1>";
$body .= "<div>Please click the link below to accept Invitation<br/><a href='".BASE_URL."/discs/changeAccept/".$this->DiscTeamMember->id."' >Accept</a>";
 // echo $body; die('--');
//$body             = eregi_replace("[\]",'',$body);

$mail->IsSMTP(); // telling the class to use SMTP
//$mail->Host       = "ssl://smtp.gmail.com"; // SMTP server
$mail->SMTPDebug  = 1;                     // enables SMTP debug information (for testing)
                                           // 1 = errors and messages
                                           // 2 = messages only
$mail->SMTPAuth   = true;                  // enable SMTP authentication
$mail->SMTPSecure = "ssl";                 // sets the prefix to the servier
$mail->Host       = "smtp.gmail.com";      // sets GMAIL as the SMTP server
$mail->Port       = 465;                   // set the SMTP port for the GMAIL server
$mail->Username   = "rohansunpreet@gmail.com";  // GMAIL username
$mail->Password   = "mangalsing";            // GMAIL password

$mail->SetFrom('rohansunpreet@gmail.com', 'PRSPS');

//$mail->AddReplyTo("user2@gmail.com', 'First Last");

$mail->Subject    = "MyBridge Team Invitation";

//$mail->AltBody    = "To view the message, please use an HTML compatible email viewer!"; // optional, comment out and test

$mail->MsgHTML($body);

$address = $userInfo['userEmailid'];
$mail->AddAddress($address, "user2");

//$mail->AddAttachment("images/phpmailer.gif");      // attachment
//$mail->AddAttachment("images/phpmailer_mini.gif"); // attachment

if(!$mail->Send()) {
  echo "Mailer Error: " . $mail->ErrorInfo;
} else {
  echo "Message sent!";
}
  
                 
              }

               // $this->Session->setFlash(__("Invitation sent Successfully","invitation"));

    $this->Session->setFlash(__("Invitation sent Successfully"));
              $this->redirect('/discs/teamdetail');
        }


        //For header_min area
       


        
         //For header_min area
       // $userdata= $this->User->find('all',array('conditions' => array('User.role' => 2), 'fields' => array('Users.id', 'Users.email', 'Users.username')));
         $userdata= $this->User->unbindModel(array('hasOne' => array('Profile')));
         $userdata= $this->User->unbindModel(array('hasMany' => array('Post','UserSkill','UserContactAdvice','UserCertification','EducationDetail','UserMilestone','OtherDetail','BusinessDetail','JobDetail','SelectionDetail','InterviewDetail','UserExperience','BusinessConnection')));
        $userdata=$this->User->find('all',array('fields'=>array('User.id','User.username')));
        //$userdata = $this->User->find('all');
        foreach($userdata as $user){
         //echo "<pre>"; print_r($user['User']);
          $newUserArr[]=array("value"=>$user['User']['id'],"label"=>$user['User']['username']);
        }
        $encodedData= json_encode($newUserArr);
        // echo "<pre>"; print_r( $encodedData); die;    
         $this->set('userdata',$userdata);
         $this->set('newUserArr', $newUserArr);
         $this->set('encodedData',$encodedData);
        }
        else{
          echo "Invalid Team Details"; exit;
        }
        


      }

// ================ get token with ajax ==========================================
       public function friendstoken(){
    $q = $_REQUEST[q];
  // print_r($_REQUEST); die;
 

     // Get all connection ids for which the current user sent the connection request.
  $sent_connections = $this->UserConnection->find('list', array('conditions' => array('UserConnection.status' => 'connected', 'favorite IN' => array('receiver', 'none'), 'receiver_id' => $this->Session->read('User.id')), 'fields' => array('sender_id')));

   // Get all connection ids for which the connection request is sent to the current user.
  $received_connections = $this->UserConnection->find('list', array('conditions' => array('UserConnection.status' => 'connected', 'favorite IN' => array('sender', 'none'), 'sender_id' => $this->Session->read('User.id')), 'fields' => array('receiver_id')));

  // Get all ids in one array so that it can be used in IN clause to get the connection's info.
  $all_connection_ids = array_merge(array_values($sent_connections), array_values($received_connections));

  $all_connections_info = $this->User->find('all', array('conditions' => array('User.id' => array_values($all_connection_ids),'Profile.first_name LIKE '=> '%'.$q.'%'), 'fields' => array('User.id', 'User.email', 'Profile.first_name', 'Profile.last_name', 'Profile.image_url', 'User.online_status')));
            $this->set('contacts', $all_connections_info);

         

 //     $userdata= $this->User->unbindModel(array('hasOne' => array('Profile')));
 //         $userdata= $this->User->unbindModel(array('hasMany' => array('Post','UserSkill','UserContactAdvice','UserCertification','EducationDetail','UserMilestone','OtherDetail','BusinessDetail','JobDetail','SelectionDetail','InterviewDetail','UserExperience','BusinessConnection')));
       
 // //$userdata=$this->User->find('all',array('conditions'=>array('User.username LIKE '=> '%'.$q.'%'),array('fields'=>array('User.id','User.username')))); 
 //        $userdata=$this->User->find('all', array('conditions' => array('User.username LIKE '=> '%'.$q.'%','User.id !=' => USERID),
 //       'fields' => array('User.id','User.username')));
        //echo "<pre>"; print_r( $userdata); die; 
        foreach($all_connections_info as $user){
         //echo "<pre>"; print_r($user['User']);
       $ids=($user['User']['id']);
       $name=($user['Profile']['first_name']." ".$user['Profile']['last_name']);
       $image = ($user['Profile']['image_url']);
       if($image == ''){
        $image = 'shareuser1.jpg';
       }
          $newUserArr[]=array("id"=>$ids,"name"=>$name,"image"=>$image);

        }
        // $userArr=array();
        // foreach($userdata as $userd){
        //   //echo "<pre>";print_r($userd['User']);
        //   $userArr[]=$userd['User'];
        // }
       //print_r($newUserArr);
       echo $encodedData= json_encode($newUserArr);
      
       // echo $encodedData='[
       //          {id: 7, name: "Ruby"},
       //          {id: 11, name: "Python"},
       //          {id: 13, name: "JavaScript"},
       //          {id: 17, name: "ActionScript"},
       //          {id: 19, name: "Scheme"},
       //          {id: 23, name: "Lisp"},
       //          {id: 29, name: "C"},
       //          {id: 31, name: "Fortran"},
       //          {id: 37, name: "Visual Basic"},
       //          {id: 41, name: "C"},
       //          {id: 43, name: "C++"},
       //          {id: 47, name: "Java"}
       //      ]';
    die;
   }

// ================ get token with ajax ==========================================
       public function token(){
    $q = $_REQUEST[q];
  // print_r($_REQUEST); die;
     $userdata= $this->User->unbindModel(array('hasOne' => array('Profile')));
         $userdata= $this->User->unbindModel(array('hasMany' => array('Post','UserSkill','UserContactAdvice','UserCertification','EducationDetail','UserMilestone','OtherDetail','BusinessDetail','JobDetail','SelectionDetail','InterviewDetail','UserExperience','BusinessConnection')));
       
 //$userdata=$this->User->find('all',array('conditions'=>array('User.username LIKE '=> '%'.$q.'%'),array('fields'=>array('User.id','User.username')))); 
        $userdata=$this->User->find('all', array('conditions' => array('User.username LIKE '=> '%'.$q.'%','User.id !=' => USERID),
       'fields' => array('User.id','User.username')));
        //echo "<pre>"; print_r( $userdata); die; 
        foreach($userdata as $user){
         //echo "<pre>"; print_r($user['User']);
       $ids=($user['User']['id']);
          $newUserArr[]=array("id"=>$ids,"name"=>$user['User']['username']);
        }
        // $userArr=array();
        // foreach($userdata as $userd){
        //   //echo "<pre>";print_r($userd['User']);
        //   $userArr[]=$userd['User'];
        // }
       // print_r($userArr);
       echo $encodedData= json_encode($newUserArr);
      
       // echo $encodedData='[
       //          {id: 7, name: "Ruby"},
       //          {id: 11, name: "Python"},
       //          {id: 13, name: "JavaScript"},
       //          {id: 17, name: "ActionScript"},
       //          {id: 19, name: "Scheme"},
       //          {id: 23, name: "Lisp"},
       //          {id: 29, name: "C"},
       //          {id: 31, name: "Fortran"},
       //          {id: 37, name: "Visual Basic"},
       //          {id: 41, name: "C"},
       //          {id: 43, name: "C++"},
       //          {id: 47, name: "Java"}
       //      ]';
    die;
   }
// = ==================== change accepted ==========================
   public function changeAccept($memberid=null) {
    
      //  $memberid=1;
        if(!empty($memberid)){

              $DiscInviteUserData=$this->DiscTeamMember->find('all', array('conditions' => array('DiscTeamMember.id '=> $memberid )));

            //  print_r($DiscInviteUserData); die;
               // echo "<pre>"; print_r($DiscInviteUserData[0]['DiscTeamMember']['is_accepted']);die;
                if(@$DiscInviteUserData[0]['DiscTeamMember']['is_accepted'] == 0){
                   //echo $memberid;die;
                    $disc_member=array();
                    $disc_member['DiscTeamMember']['is_accepted']= 1;
                     $disc_member['DiscTeamMember']['id']=$memberid;
                     $data=$this->DiscTeamMember->save($disc_member);

                    
                }
                $this->redirect('/discs/team/'.$DiscInviteUserData[0]['DiscTeamMember']['disc_team_id']);
             // $disc_member['DiscTeamMember']['member_id']= $idsArr[$i];
             //  $this->DiscTeamMember->create();
             //  $data=$this->DiscTeamMember->save($disc_member);

                
        }

  }
  //====================================
  // ===================== FILES FUNCTION TO GET FILES OPERATIONS =========================
      public function teamdetail($id=null){

        // $member_detail = $this->DiscTeamMember->find('all');
      if($id){
        $logged_user = $this->Auth->user('id');
        $this->set('logged_user',$logged_user);
            //  ---------- GET TEAM DETAIL  --------------------
        $team_data = $this->DiscTeam->find('first', array(
        'conditions' => array('DiscTeam.id' => $id)));
        $this->set('team_data',$team_data);
             //print_r($team_data); die;
        $logginUser =  $this->Auth->user('id');
                   if($team_data['DiscTeam']['created_by'] == $logginUser){
                    $this->set('is_owner',1);
                   }
                   else{
                    $this->set('is_owner',0);
                   }
           
      


          // -------- GET TEAM MEMBER DETAILS HERE -----------------
      //  $this->set('team_id',$id);
        $member_detail = $this->DiscTeamMember->find('all', array(
        'conditions' => array('DiscTeamMember.disc_team_id' => $id,'DiscTeamMember.is_accepted'=> '1')));
        $this->set('member_detail',$member_detail);

            }
      }
  // ====================================================================================

  // ===================== FILES FUNCTION TO GET FILES OPERATIONS =========================
      public function deleteteam($id=null){

      if($id){
            //  ---------- GET TEAM DETAIL  --------------------
     $this->DiscTeam->delete($id);
       $this->redirect('/discs/files/');


      }
    }
    //================== create Team ====================================================
    public function create(){
     // print_r($_REQUEST); die;
        ini_set('memory_limit', '512M');
        $this->layout='profile_page';
      $dir_val = $_REQUEST['dir_val'];
      $this->set('dir_val',$dir_val);
      if(isset($_REQUEST['submit'])){
       $fname = $_REQUEST['newDir'];
       $dirpath = $_REQUEST['dirpath']; 
         if($fname !='' && $dirpath !='' ){
     $dirp =  $dirpath;
  //   echo $dirp; die;
      $filename =  $fname;  
     mkdir($dirp.'/'.$filename);
     chmod($dirp.'/'.$filename, 0777);
     $FolderEntry = array();
     $FolderEntry['file_name'] = $filename;
     $FolderEntry['file_path'] = $dirp.$filename;
     $FolderEntry['uploaded_by'] = LOGGEDUSERID;
     $this->UploadedFile->save($FolderEntry);

  }
  // echo $dirpath; die;
  $this->Session->setFlash('Folder created successfully');
 $this->redirect('/discs/files?gopath='.$dirpath);
    
    }
  }



    //===================================================================================
//=======================================================================================
// function rename(){
//   $dir_val = $_REQUEST['dir_val'];
//   $filename = $_REQUEST['file_checked'][0];

//    $split_name = explode('.',$filename);
//     $firstName = $split_name[0];
//     $exten = $split_name[1];
//   $this->set('oldname',$filename);
//   $this->set('firstName',$firstName);
//   $this->set('filepath',$dir_val);
//   $this->set('exten',$exten);

 


//   if(isset($_REQUEST['submit'])){
//     // GET NEW VALUE HERE
//    $new_val = $_REQUEST['new_name'];
//     $file_dir = $_REQUEST['file_dir'];  
//     $old_name = $_REQUEST['firstName'];
//     $extension = $_REQUEST['extension'];
//     $oldname = $_REQUEST['oldname'];
//    //echo $file_dir.$old_name.'====='.$file_dir.$new_val; die; 
//     if(is_dir($file_dir.'/'.$old_name)){
//       rename($file_dir.$old_name,$file_dir.'/'.$new_val);
//     $this->Session->setFlash('Folder renamed Successfully');
//      $this->redirect('/discs/files/');
//     }else if($file_dir !='' && $new_val !='' ){
// //echo $file_dir.$oldname,$file_dir.$new_val.'.'.$extension; die;
//      if(rename($file_dir.$oldname,$file_dir.$new_val.'.'.$extension)){
//         $this->Session->setFlash('File renamed Successfully');
//         $this->redirect('/discs/files/');
//      }
//      else{
//        // print_r(error_get_last());
//         $this->redirect('/discs/files/');
//      }

//     }
//     die;


//     rename($dir_val.$filename,$dir_val.'/'.$new_val);
//   }
  
  
  
//  // echo $dir_val.$filename; die;
// }



//=======================================================================================
function rename(){


  $dir_val = $_REQUEST['dir_val'];

  $filename = $_REQUEST['file_checked'][0];

  $oldFile= $dir_val.$filename;

 //echo $oldFile; die;

   $split_name = explode('/',$filename);
   $arrayLength = count($split_name); 
   $lastfile = explode('/',$split_name[$arrayLength - 1]);
    $main_name = explode('.',$lastfile[0]);
   // print_r($lastfile); die;
    $firstName = $main_name[0];
    $exten = $main_name[1];
  $this->set('oldname',$lastfile[0]);
  $this->set('firstName',$firstName);
  $this->set('filepath',$dir_val);
  $this->set('exten',$exten);
  $this->set('filePath',$filename);
  $this->set('oldFile',$oldFile);

 


  if(isset($_REQUEST['submit'])){
    // GET NEW VALUE HERE
   $new_val = $_REQUEST['new_name'];
    $file_dir = $_REQUEST['file_dir'];  
    $old_name = $_REQUEST['firstName'];
    $extension = $_REQUEST['extension'];
    $oldname = $_REQUEST['oldname'];
    $filePath1 = $_REQUEST['filePath'];
    $loggedUser = $_REQUEST['loggedUser'];
    $oldFile = $_REQUEST['oldFile'];
    $filePath = dirname($filePath1);
  
  $newPathDir =  $file_dir.$new_val;
  $newPath =  $file_dir.$new_val.'.'.$extension;
  $newFileName =  $new_val.'.'.$extension;
  $newFoldName =  $new_val;
    

if(is_dir($file_dir.'/'.$old_name)){

 $selectFile = $this->ShareDocument->find('all',array('conditions'=>array('ShareDocument.document_path'=> $oldFile)));
 //print_r($selectFile); die;
 if(count($selectFile) > 0){
    foreach($selectFile as $selected_file){

    $updateid = $selected_file['ShareDocument']['id'];
    $updateField = array();
    $updateField['ShareDocument']['id'] = $updateid;
    $updateField['ShareDocument']['document_path'] = $newPathDir;
    $this->ShareDocument->save($updateField);
    }
 }

    $uploadData = $this->UploadedFile->find('first',array('conditions'=>array('UploadedFile.file_path'=> $oldFile))); 
  //  print_r($uploadData); die;  
$uploadId = $uploadData['UploadedFile']['id'];
// echo $uploadId; die;
    $modifyUpload = array();
    $modifyUpload['UploadedFile']['id'] = $uploadId;
    $modifyUpload['UploadedFile']['file_name'] = $new_val;
    $modifyUpload['UploadedFile']['file_path'] = $newPathDir;
    $modifyUpload['UploadedFile']['modified_by'] = LOGGEDUSERNAME;
    $modifyUpload['UploadedFile']['modified_at'] = date('Y/m/d h:i:s', time());
    $this->UploadedFile->save($modifyUpload);
      rename($file_dir.$old_name,$newPathDir);
    $this->Session->setFlash('Folder renamed Successfully');
     $this->redirect('/discs/files');

    } else{
  
      
      $selectFile = $this->ShareDocument->find('all',array('conditions'=>array('ShareDocument.document_path'=> $oldFile)));
 //print_r($selectFile); die;
 if(count($selectFile) > 0){
    foreach($selectFile as $selected_file){

    $updateid = $selected_file['ShareDocument']['id'];
    $updateField = array();
    $updateField['ShareDocument']['id'] = $updateid;
    $updateField['ShareDocument']['document_path'] = $newPath;
    $this->ShareDocument->save($updateField);
    }
 }

    $uploadData = $this->UploadedFile->find('first',array('conditions'=>array('UploadedFile.file_path'=> $oldFile))); 
    //print_r($uploadData); die;  
$uploadId = $uploadData['UploadedFile']['id'];
// echo $uploadId; die;
    $modifyUpload = array();
    $modifyUpload['UploadedFile']['id'] = $uploadId;
    $modifyUpload['UploadedFile']['file_name'] = $newFileName;
    $modifyUpload['UploadedFile']['file_path'] = $newPath;
    $modifyUpload['UploadedFile']['modified_by'] = LOGGEDUSERNAME;
    $modifyUpload['UploadedFile']['modified_at'] = date('Y/m/d h:i:s', time());
    $this->UploadedFile->save($modifyUpload);

      rename($oldFile,$newPath);
    $this->Session->setFlash('File has been successfully renamed');
    $this->redirect('/discs/files');

    }
  }
}

// ================================================================

//=======================================================================================
function sharerename(){


  $dir_val = $_REQUEST['dir_val'];

  $filename = $_REQUEST['file_checked'][0];

    //echo $filename; die;

   $split_name = explode('/',$filename);
   $arrayLength = count($split_name); 
   $lastfile = explode('/',$split_name[$arrayLength - 1]);
    $main_name = explode('.',$lastfile[0]);
   // print_r($lastfile); die;
    $firstName = $main_name[0];
    $exten = $main_name[1];
  $this->set('oldname',$lastfile[0]);
  $this->set('firstName',$firstName);
  $this->set('filepath',$dir_val);
  $this->set('exten',$exten);
  $this->set('filePath',$filename);

 


  if(isset($_REQUEST['submit'])){
    // GET NEW VALUE HERE
   $new_val = $_REQUEST['new_name'];
    $file_dir = $_REQUEST['file_dir'];  
    $old_name = $_REQUEST['firstName'];
    $extension = $_REQUEST['extension'];
    $oldname = $_REQUEST['oldname'];
    $filePath1 = $_REQUEST['filePath'];
    $loggedUser = $_REQUEST['loggedUser'];
    $filePath = dirname($filePath1);
  $newPath =  $filePath.'/'.$new_val.'.'.$extension;
  $newPathDir =  $filePath.'/'.$new_val;
  $newFileName =  $new_val.'.'.$extension;
  $newFoldName =  $new_val;
//  echo $new_val; die;
 // $newName = $new_val.'.'.$extension;


//echo $filePath1; die;
  if(is_dir($filePath1)){
 $selectFile = $this->ShareDocument->find('all',array('conditions'=>array('ShareDocument.document_path'=> $filePath1)));
 //print_r($selectFile); die;
 if(count($selectFile) > 0){
    foreach($selectFile as $selected_file){

    $updateid = $selected_file['ShareDocument']['id'];
    $updateField = array();
    $updateField['ShareDocument']['id'] = $updateid;
    $updateField['ShareDocument']['document_path'] = $newPathDir;
    $this->ShareDocument->save($updateField);
    }
 }

    $uploadData = $this->UploadedFile->find('first',array('conditions'=>array('UploadedFile.file_path'=> $filePath1))); 
    //print_r($uploadData); die;  
$uploadId = $uploadData['UploadedFile']['id'];
// echo $uploadId; die;
    $modifyUpload = array();
    $modifyUpload['UploadedFile']['id'] = $uploadId;
    $modifyUpload['UploadedFile']['file_path'] = $newPathDir;
    $modifyUpload['UploadedFile']['file_name'] = $new_val;
    $modifyUpload['UploadedFile']['modified_by'] = LOGGEDUSERNAME;
    $modifyUpload['UploadedFile']['modified_at'] = date('Y/m/d h:i:s', time());
    $this->UploadedFile->save($modifyUpload);

   
      rename($filePath1,$filePath.'/'.$new_val);
    $this->Session->setFlash('Folder renamed Successfully');
     $this->redirect('/discs/sharedpersons');

    } else{
      $selectFile = $this->ShareDocument->find('all',array('conditions'=>array('ShareDocument.document_path'=> $filePath1)));
 //print_r($selectFile); die;
 if(count($selectFile) > 0){
    foreach($selectFile as $selected_file){

    $updateid = $selected_file['ShareDocument']['id'];
    $updateField = array();
    $updateField['ShareDocument']['id'] = $updateid;
    $updateField['ShareDocument']['document_path'] = $newPath;
    $this->ShareDocument->save($updateField);
    }
 }

    $uploadData = $this->UploadedFile->find('first',array('conditions'=>array('UploadedFile.file_path'=> $filePath1))); 
    //print_r($uploadData); die;  
$uploadId = $uploadData['UploadedFile']['id'];
// echo $uploadId; die;
    $modifyUpload = array();
    $modifyUpload['UploadedFile']['id'] = $uploadId;
    $modifyUpload['UploadedFile']['file_path'] = $newPath;
    $modifyUpload['UploadedFile']['file_name'] = $newFileName;
    $modifyUpload['UploadedFile']['modified_by'] = LOGGEDUSERNAME;
    $modifyUpload['UploadedFile']['modified_at'] = date('Y/m/d h:i:s', time());
    $this->UploadedFile->save($modifyUpload);

      rename($filePath1,$newPath);
    $this->Session->setFlash('File has been successfully renamed');
    $this->redirect('/discs/sharedpersons');

    }
  }
}



 /* $selectFile = $this->ShareDocument->find('all',array('conditions'=>array('ShareDocument.document_path'=> $filePath1)));
 if(count($selectFile) > 0){
    foreach($selectFile as $selected_file){

    $updateid = $selected_file['ShareDocument']['id'];
    $updateField = array();
    $updateField['ShareDocument']['id'] = $updateid;
    $updateField['ShareDocument']['document_path'] = $newPath;
    $this->ShareDocument->save($updateField);
    }
 }

    $uploadData = $this->UploadedFile->find('first',array('conditions'=>array('UploadedFile.file_path'=> $filePath1))); 
    //print_r($uploadData); die;  
$uploadId = $uploadData['UploadedFile']['id'];
 //echo $uploadId; die;
 date_default_timezone_set("Asia/Calcutta");
    $modifyUpload = array();
    $modifyUpload['UploadedFile']['id'] = $uploadId;
    $modifyUpload['UploadedFile']['file_path'] = $newPath;
    $modifyUpload['UploadedFile']['file_name'] = $newName;
    $modifyUpload['UploadedFile']['modified_by'] = LOGGEDUSERNAME;
    $modifyUpload['UploadedFile']['modified_at'] = date('Y/m/d h:i:s', time());
   //print_r($modifyUpload); die;
    $this->UploadedFile->save($modifyUpload);

    rename($filePath1,$newPath);
  $this->redirect('/discs/sharedpersons');*/


//=================== Share documents =======================
function sharedfile(){
   ini_set('memory_limit', '512M');
        $this->layout='profile_page';
        
    if(!empty($_GET ['uid'])){

        $uid=$_GET ['uid'];

        $loginuserid=USERID; 

        $count = array();
         // $permissionData=$this->ShareDocument->find('all', array('conditions' => array('ShareDocument.share_with_users_id '=> $uid)));
         $permissionData=$this->ShareDocument->find('all', array('conditions' => array('ShareDocument.user_id '=> $uid, 'ShareDocument.share_with_users_id '=> USERID)));
         //print_r($permissionData); die;
         $perm_arr = array();
         $i=0;
        //  print_r($permissionData); die("---");
         foreach($permissionData as $file){
        
         $sharedFile = $this->ShareDocument->find('all',array('conditions'=>array('ShareDocument.document_path'=>$file['UploadedFile']['file_path'])));
         $count = count($sharedFile);
         $perm_arr[$i]['ShareDocument']=$file['ShareDocument'];
         $perm_arr[$i]['Profile']=$file['Profile'];
         $perm_arr[$i]['UploadedFile']=$file['UploadedFile'];
         $perm_arr[$i]['count'] = $count;
         $i++;
         
         }
       // print_r($perm_arr); die('--');
        $this->set('count',$count);
         $this->set('permissionData',$perm_arr); 


         // print_r($permissionData)  ;  die;    
        $newPermissionArr=array();
        // $newPermissionArr['is_hide']='29';
        $newPermission=array();
        foreach($permissionData as $permission){

        $sharedFile = $this->ShareDocument->find('all',array('conditions'=>array('ShareDocument.document_path'=>$file['UploadedFile']['file_path'])));
         $count = count($sharedFile);
         //echo $count; die;
         }

        $permission['ShareDocument']['first_name']=$permission['Profile']['first_name'];
        $permission['ShareDocument']['last_name']=$permission['Profile']['last_name'];
        $permission['ShareDocument']['image_url']=$permission['User']['image_url'];
        $newPermissionArr[]=$permission['ShareDocument'];

            
         }
         foreach($newPermissionArr as $PermissionData){

                 $newPermission[]['document_path']=$PermissionData['document_path'];
            }
           // echo "<pre>"; print_r($newPermissionArr);die;
            $this->set('newPermission',$permissionData);
            $this->set('is_hide','1');
            $this->set('uid',$uid);
    }
// ================================================================================


//=================== share function ==============================================
function teamdisk(){
   
   $this->DiskTeam->find('all',array('conditions'=>array('DiscTeam.')));
}



//=================================================================================

//=================== share function ==============================================
function share($path=null){

 $this->layout='profile_page';
  if(!empty($_GET ['path'])){

    $file_path=$_GET ['path'];
    $this->set('file_path',$file_path);
  }
  $path = $this->request->query('path');
//echo $path; die;
$filename1=explode("/",$path);
$countIndex=count($filename1);
$filename = $filename1[$countIndex-1];
$this->set('filename',$filename);
$userId=$this->Auth->user('id');

$totalM = $this->ShareDocument->find('all',array('conditions'=>array('ShareDocument.document_path'=> $path,'ShareDocument.is_owner'=> '0')));
$totalMembers  = count($totalM);
$this->set('members',$totalMembers);


  $shareFile = $this->ShareDocument->find('all',array('conditions'=>array('ShareDocument.document_path'=> $path,'ShareDocument.is_owner'=> '0')));
  // print_r($shareFile); die;
  //$this->set('shareFile',$shareFile);
$profileData = array();
$i=0;
  foreach($shareFile as $share=>$k){
    // print_r($k['']); die;
      $shareId=$k['ShareDocument']['share_with_users_id'];
      $profileData[$i] = $this->Profile->find('all',array('conditions'=>array('Profile.user_id'=>$shareId)));
      $profileData[$i]['permissions'] = $k['ShareDocument']['users_permission'];
      $profileData[$i]['shared_doc_id'] = $k['ShareDocument']['id'];
$i++;
  }

      $this->set('profileData',$profileData);

$member_detail = $this->DiscTeamMember->find('all', array(
        'conditions' => array('DiscTeamMember.disc_team_id' => $id,'DiscTeamMember.is_accepted'=> '1')));
        $this->set('member_detail',$member_detail);

 $user_id = $this->Auth->user('id');
 $logged_user = $this->User->find('first',array('conditions' => array('User.id'=>$user_id)));
// print_r($logged_user); die;
$logged_id = $logged_user['Profile']['user_id'];
       $owner_name = $logged_user['Profile']['first_name'].$logged_user['Profile']['last_name'];
        $this->set('logged_user',$owner_name);
        $this->set('logged_id',$logged_id);

$isFileShared = $this->ShareDocument->find('first',array('conditions' => array('ShareDocument.document_path'=>$file_path)));



$owner_detail = $this->ShareDocument->find('first',array('conditions' => array('ShareDocument.document_path'=>$file_path,'ShareDocument.is_owner'=> 1)));

$ownerName = $owner_detail['Profile']['first_name'].$owner_detail['Profile']['last_name'];
$ownerId = $owner_detail['Profile']['user_id'];
$this->set(ownerName,$ownerName);
$this->set(ownerId,$ownerId);
// print_r($owner_detail); die;
  $owner_name = $owner_detail['Profile']['first_name'].$owner_detail['Profile']['last_name'];
  //echo $owner_detail['Profile']['first_name'].['Profile']['last_name']; die;
  $this->set('isFileshare',count($isFileShared));
  $this->set('ownerName',$owner_name);
  
  if($this->request->is('post')){ 
          if(!empty($this->request->data['share_user'])){
            $shareUserdata=$this->request->data['share_user'];
            $ShareArr=explode(",",@$shareUserdata);
          }
          $filePath=$this->request->data['filePath'];
           
          $userId=$this->Auth->user('id');
          $permission=$this->request->data['permission']; 

  $findOwner = $this->ShareDocument->find('all',array('conditions'=> array('ShareDocument.document_path'=> $filePath, 'ShareDocument.is_owner'=>1)));
        if(count($findOwner) == '0'){
          $ownerData = array();
          $ownerData['ShareDocument']['document_path'] = $filePath;
          $ownerData['ShareDocument']['user_id'] = $userId;
          $ownerData['ShareDocument']['is_owner'] = '1';
          $this->ShareDocument->save($ownerData);
        }

          //print_r($owner_detail); die;
          $tempArr=array();

          foreach($ShareArr as $key => $share)
          {
                 $tempArr[$key]['document_path']=$filePath;
                 $tempArr[$key]['user_id']=$userId;
                 $tempArr[$key]['share_with_users_id']=$share;
                 $tempArr[$key]['users_permission']=$permission;
                

          }
          foreach($tempArr as $temp){
         // echo $temp['document_path']; die;
        //    print_r($temp); die;
              $ShareDocument['ShareDocument']['document_path']=$temp['document_path'];
              $ShareDocument['ShareDocument']['user_id']=$temp['user_id'];
              $ShareDocument['ShareDocument']['share_with_users_id']=$temp['share_with_users_id'];
              $ShareDocument['ShareDocument']['users_permission']=$temp['users_permission'];
              $this->ShareDocument->create();
              $this->ShareDocument->save($ShareDocument);
          }
        //  echo dirname($file_path); die;
           $this->redirect('/discs/files?gopath='.dirname($file_path));
    }
}
//===========================================================

//=== ================ share by me =============================
function sharebyme($path=null,$unsetId=null){
  $this->layout='profile_page';
  if(!empty($_GET ['path'])){


    $file_path=$_GET ['path'];
    $this->set('file_path',$file_path);
  }
  if(!empty($_GET ['unsetId'])){

      $fId=$_GET ['unsetId']; 
      $this->ShareDocument->id = $fId;
      $this->ShareDocument->delete();
      $this->Session->setFlash('Unshare File Successfully');
      $this->redirect('sharebyme');

   // $this->set('file_path',$file_path);
  }
  if($this->request->is('post')){ //the user has submitted which status to view
      //print_r($this->request->data);die;
          if(!empty($this->request->data['share_user'])){
            $shareUserdata=$this->request->data['share_user'];
            $ShareArr=explode(",",@$shareUserdata);
          }
          if(!empty($this->request->data['share_team'])){
            $shareUserdata=$this->request->data['share_team'];
            $ShareTeamArr=explode(",",@$shareUserdata);
            $TeamMemberdata=array();
            foreach($ShareTeamArr as $k=>$ShareTeam){

              $TeamMemberdata[$k]=$this->DiscTeamMember->find('all', array('conditions' => array('DiscTeamMember.disc_team_id  '=> $ShareTeam , 'DiscTeamMember.is_accepted  '=> '1' )));
          
            }
            foreach($TeamMemberdata as $TeamMember){
              foreach($TeamMember as $Team){
                 
                  $ShareArr[]=$Team['DiscTeamMember']['member_id'] ;  
              }
                  
            }
           
          }
          $filePath=$this->request->data['filePath'];
          $userId=$this->request->data['userId'];
          $permission=$this->request->data['permission']; 
          
        // print_r($ShareArr);die;
          $tempArr=array();

          foreach($ShareArr as $key => $share)
          {
                //echo $share;die("stp");
                 $tempArr[$key]['document_path']=$filePath;
                 $tempArr[$key]['user_id']=$userId;
                 $tempArr[$key]['share_with_users_id']=$share;
                 $tempArr[$key]['users_permission']=$permission;
                

          }
          foreach($tempArr as $temp){
              $ShareDocument['ShareDocument']['document_path']=$temp['document_path'];
              $ShareDocument['ShareDocument']['user_id']=$temp['user_id'];
              $ShareDocument['ShareDocument']['share_with_users_id']=$temp['share_with_users_id'];
              $ShareDocument['ShareDocument']['users_permission']=$temp['users_permission'];
              $this->ShareDocument->create();
              $this->ShareDocument->save($ShareDocument);

          }
           $this->redirect('/discs/files');
          //echo "<pre>"; print_r($tempArr);die;
    }

//     $loginUserId=USERID; 
//     $permissionData=$this->ShareDocument->find('all', array('conditions' => array('ShareDocument.share_with_users_id  '=> $loginUserId)));
// //echo "<pre>"; print_r($permissionData);die;
//    $nameIdArr=array();
//     foreach($permissionData as $key=>$permission){
      
//         if($key == 0){
//           $nameIdArr[]=$permission['ShareDocument']['user_id'];
//           $permission['ShareDocument']['first_name']=$permission['Profile']['first_name'];
//           $permission['ShareDocument']['last_name']=$permission['Profile']['last_name'];
//           $permission['ShareDocument']['image_url']=$permission['User']['image_url'];
//           $PermissionUserArr[]=$permission['ShareDocument'];
//         }
//         if(!in_array($permission['ShareDocument']['user_id'],$nameIdArr)) {

//         $permission['ShareDocument']['first_name']=$permission['Profile']['first_name'];
//         $permission['ShareDocument']['last_name']=$permission['Profile']['last_name'];
//         $permission['ShareDocument']['image_url']=$permission['User']['image_url'];
//         $PermissionUserArr[]=$permission['ShareDocument'];
//         $nameIdArr[]=$permission['ShareDocument']['user_id'];
//       }
//     }
//     $this->set('PermissionUserArr',$PermissionUserArr);

  //echo "<pre>"; print_r($PermissionUserArr);die;
   if(!empty($_GET ['uid'])){

        $uid=$_GET ['uid'];
        $loginuserid=USERID;
         $permissionData=$this->ShareDocument->find('all', array('conditions' => array('ShareDocument.share_with_users_id  '=> $uid  , 'ShareDocument.user_id '=> $loginuserid)));
         $newPermissionArr=array();
         // $newPermissionArr['is_hide']='29';
         $newPermission=array();
        foreach($permissionData as $permission){


        $permission['ShareDocument']['first_name']=$permission['Profile']['first_name'];
        $permission['ShareDocument']['last_name']=$permission['Profile']['last_name'];
        $permission['ShareDocument']['image_url']=$permission['User']['image_url'];
        $newPermissionArr[]=$permission['ShareDocument'];
            
         }
         foreach($newPermissionArr as $PermissionData){

                 $newPermission[]['document_path']=$PermissionData['document_path'];
            }
           echo "<pre>"; print_r($newPermission);die;
            $this->set('newPermission',$newPermissionArr);
            $this->set('is_hide','1');
            $this->set('uid',$uid);
    }




   
    // $userdata= $this->User->unbindModel(array('hasOne' => array('Profile')));
    // $userdata= $this->User->unbindModel(array('hasMany' => array('Post','UserSkill','UserContactAdvice','UserCertification','EducationDetail','UserMilestone','OtherDetail','BusinessDetail','JobDetail','SelectionDetail','InterviewDetail','UserExperience','BusinessConnection')));
    // $userdata=$this->User->find('all',array('fields'=>array('User.id','User.username')));
    // //$userdata = $this->User->find('all');
    // foreach($userdata as $user){
   
    //        $newUserArr[]=array("value"=>$user['User']['id'],"label"=>$user['User']['username']);
    // }
   
    // $encodedData= json_encode($newUserArr);
    
    // $teamData=$this->DiscTeam->find('all');  
    // $teamArr=array();
    // foreach($teamData as $team){
   
    //        $teamArr[]=array("value"=>$team['DiscTeam']['id'],"label"=>$team['DiscTeam']['name']);
    // } 
    // // echo "<pre>"; print_r( $teamArr); die; 
    //  $encodedTeamData= json_encode($teamArr);
    // $this->set('userdata',$userdata);
    // $this->set('newUserArr', $newUserArr);
    // $this->set('encodedData',$encodedData);
    // $this->set('encodedTeamData',$encodedTeamData);






}

//================================================================

//========================== team setting ===============================================
      public function teamsetting($id= null){
           if (!empty($this->request->data)) {
           //   print_r($this->request->data); die;
              $team_name = $this->request->data['team_name'];
              $team_id = $this->request->data['team_id'];
              $team_arr = array();
              $team_arr['DiscTeam']['id'] = $team_id; 
              $team_arr['DiscTeam']['name'] = $team_name;
              $this->DiscTeam->save($team_arr);
              $this->redirect('/discs/teamdetail/'.$team_id); 
           }


         $team_data = $this->DiscTeam->find('first', array(
        'conditions' => array('DiscTeam.id' => $id)));
       $this->set('team_data',$team_data);
       // $old_team_name = $team_data['DiscTeam']['name'];
       // $this->set('oldName',$old_team_name);
      
      }
      



//=======================================================================================
      //=================================================================================
function unshare(){
if(!empty($_GET['filepath'])){
  $filePath =  $_GET['filepath'];
  $unshareData = $this->ShareDocument->find('all',array('conditions'=>array('ShareDocument.document_path'=>$filePath)));
  foreach($unshareData as $key=>$data){
    $shareId = $data['ShareDocument']['id'];
    $this->ShareDocument->delete($shareId);
  }
}
$this->redirect('/discs/files');
}
  // ===================== FILES FUNCTION TO GET FILES OPERATIONS =========================
    public function files() {
        ini_set('memory_limit', '512M');
        $this->layout='profile_page';
     //   echo DOCUMENT_ROOT_DISC.''.USERID; die;
      $this->set("gotopath",'');
       
       if(isset($_GET['gopath'])){
         $path_goto = $_GET['gopath'];
         $this->set("gotopath",$path_goto);
       }


        //
 $Account_info = $this->DiscPaymentDetail
      ->find('count'
        , array('conditions' => array('DiscPaymentDetail.user_id = '=> USERID))
        );
        $user_id = $this->Auth->user('id');
        $this->set('user_id', $user_id);
        
        //check folder exists for logged user or not
        if(is_dir(DOCUMENT_ROOT_DISC.'/'.USERID))
  {
 // echo (" is a directory");
  }
else
  {
//  echo (" is not a directory");
   mkdir(DOCUMENT_ROOT_DISC.'/'.USERID);
     chmod(DOCUMENT_ROOT_DISC.'/'.USERID, 0777);

      mkdir(DOCUMENT_ROOT_DISC.'/'.USERID.'/Documents');
     chmod(DOCUMENT_ROOT_DISC.'/'.USERID.'/Documents', 0777);

      mkdir(DOCUMENT_ROOT_DISC.'/'.USERID.'/Music');
     chmod(DOCUMENT_ROOT_DISC.'/'.USERID.'/Music', 0777);

      mkdir(DOCUMENT_ROOT_DISC.'/'.USERID.'/Pictures');
     chmod(DOCUMENT_ROOT_DISC.'/'.USERID.'/Pictures', 0777);

      mkdir(DOCUMENT_ROOT_DISC.'/'.USERID.'/Trash');
     chmod(DOCUMENT_ROOT_DISC.'/'.USERID.'/Trash', 0777);

      mkdir(DOCUMENT_ROOT_DISC.'/'.USERID.'/Videos');
     chmod(DOCUMENT_ROOT_DISC.'/'.USERID.'/Videos', 0777);
  }

        //For header_min area
        $profile_details = $this->Profile->find('first',array('conditions'=>array('Profile.user_id'=>$this->Auth->user('id'))));
        $this->set('profile_details', $profile_details);
        //count network users
        $countnetwork = $this->connections(array_values(array($this->Auth->user('id'))));
        $this->set('countnetwork', $countnetwork);

        //Count posts for header_mid
        $postcount = $this->Post->find('all', array('conditions' => array('Post.type'=>'HP','Post.status'=>'publish', 'Post.user_id'=>array_values(array($this->Auth->user('id'))))));
        $this->set('countposts', count($postcount));
         //For header_min area
    // GET ALL TEAMS 
 $this->set('account_updated',$Account_info);
       //  $get_teams = $this->DiscTeam->find('all');


        
    }
    // ==================================================================================

   //=================================
    public function getfiles() {
    
  if(isset($_REQUEST['dir_path']) && $_REQUEST['dir_path'] != ''){
    //  echo $_REQUEST['dir_path']; die;
      $dir_path = $_REQUEST['dir_path'];
      echo '<tr><th>Name</th><th>Modified</th><th style="width:8px;"></th><th>Share With</th></tr>';

      $this->listFolderFiles($dir_path);
  }

    die;
    }

    //=============get file trash

        public function getfilestrash() {
    
  if(isset($_REQUEST['dir_path']) && $_REQUEST['dir_path'] != ''){
      //echo $_REQUEST['dir_path']; die;
      $dir_path = $_REQUEST['dir_path'];
      echo '<tr><th>Name</th><th>Date Modified</th><th>Actions</th></tr>';

      $this->listFolderFilesTrash($dir_path);
  }

    die;
    }
    //====================================
    //================ remove_invite ==============
public function removeInvite($id= null){
  
    if($id){
      $table_id = $this->DiscTeamMember->find('first', array(
        'conditions' => array('DiscTeamMember.id' => $id)));
       $this->set('table_id',$table_id);


      $this->DiscTeamMember->delete($id);
      $this->redirect('/discs/teamdetail/');
    }




}
//=================================================
//================  create Team  ====================
    public function createTeam(){
    $newName = $_REQUEST['newTeamName'];
    $user_id = $this->Auth->user('id');
    if($this->request->is('post')){
     $store_files = array();
            $store_files['DiscTeam']['name'] = $newName;
            $store_files['DiscTeam']['created_by'] = $user_id;
            $this->DiscTeam->save($store_files);
            $new_team_id = $this->DiscTeam->id;
           
    $store_members = array();
    $store_members['DiscTeamMember']['disc_team_id'] = $new_team_id;
    $store_members['DiscTeamMember']['member_id'] = $user_id;
    $store_members['DiscTeamMember']['is_accepted'] = 1;
    $store_members['DiscTeamMember']['is_owner'] = 1;
     $this->DiscTeamMember->save($store_members);

    $this->Session->setFlash(__("Team Created Successfully"));
   //$this->Session->setFlash('This message is for form 1.', 'default', array(), 'form1');

            $this->redirect('/discs/team/'.$new_team_id);
           
             die;
            }

          }
    


// =======================================
    public function makedir(){
     $fname = $_REQUEST['folder_name'];
    $dirpath = $_REQUEST['dir_path'];

  if($fname !='' && $dirpath !='' ){
  
     $dirp =  $dirpath;

      $filename =  $fname;  
     
    //   echo $dirp.'/'.$filename; die;
     mkdir($dirp.'/'.$filename);
     chmod($dirp.'/'.$filename, 0777);

  }
  else{
    echo "Please select the folder first";
    }
  die;
    
    }
    
  
   

   // ================= DOWNLOAD FILES =========================
   // ================= DOWNLOAD FILES =========================
   public function downloadfiles(){
    // Get real path for our folder
    $dir_val = $_REQUEST['dir_val'];
    $file_checked = $_REQUEST['file_checked'];
 
    $fileNamesArr = $file_checked;
  
    $file_path = realpath($dir_val);

    if(count($fileNamesArr) =='1' && !is_dir($file_path.'/'.$fileNamesArr[0])){
      $this->set('sigle_file',true);
     $filePath =  $file_path.'/'.$fileNamesArr[0];
      $this->set('filePath',$filePath);
    


    
       $name_zip = $fileNamesArr[0];
    $archive_file_name=$name_zip;
    $this->set('archive_file_name',$archive_file_name);
    //  print_r($fileNamesArr);die('--');
    }
    else{
      $this->set('sigle_file',false);



   
     // Making zip
    $name_zip = time().'.zip';
    $archive_file_name=$name_zip;
    $this->set('archive_file_name',$archive_file_name);
   
    $zip = new ZipArchive();  
    if ($zip->open('disc_files/'.$archive_file_name, ZIPARCHIVE::CREATE )!==TRUE) {
    exit("cannot open <$archive_file_name>\n");
    }
   
   
   
    foreach($fileNamesArr as $files)
    {
    //  echo $file_path.'/'.$files;
    //  echo "<br/>";
    //==============================
    if(is_dir($file_path.'/'.$files)){
    $folder_name=basename($files).'/';
   
    $rootPath = $file_path.'/'.$files;
    $files2 = new RecursiveIteratorIterator(
      new RecursiveDirectoryIterator($file_path.'/'.$files),
      RecursiveIteratorIterator::LEAVES_ONLY
    );
  //  print_r($files2); die;
   
    foreach ($files2 as $name => $file)
    {
 
    // Skip directories (they would be added automatically)
  
 
    if (!$file->isDir())
    {
   
        // Get real and relative path for current file
       $filePath = $file->getRealPath();
      // echo "<br/>";
        $relativePath = substr($filePath, strlen($rootPath) + 1);
    //echo "<br/>";
        // Add current file to archive
       
        $zip->addFile($filePath, $folder_name.$relativePath);
    }
}
}
if(is_file($file_path.'/'.$files)){
 
$zip->addFile($file_path.'/'.$files,$files);
}
}
    //==============================
     
     
    
  //  print_r($zip);die('----');
    $zip->close();
  }
     }
// ================================================================

      // ================= DOWNLOAD FILES =========================
   public function downloadfilesshared(){
   // print_r($_REQUEST); die('--');
    // Get real path for our folder
    //$dir_val = $_REQUEST['dir_val'];
    $file_checked = $_REQUEST['file_checked'];
  
    $fileNamesArr = $file_checked;
   // print_r($fileNamesArr);die('--');
   // $file_path = realpath($dir_val);
    
     // Making zip
     $name_zip = time().'.zip';
    $archive_file_name=$name_zip;
    $this->set('archive_file_name',$archive_file_name);
    
    $zip = new ZipArchive();   
    if ($zip->open('disc_files/'.$archive_file_name, ZIPARCHIVE::CREATE )!==TRUE) {
    exit("cannot open <$archive_file_name>\n");
    }
    
    
    
    foreach($fileNamesArr as $files)
    {
    //  echo $file_path.'/'.$files;
    //  echo "<br/>";
    //==============================
    if(is_dir($files)){
    $folder_name=basename($files).'/';
    
    //$rootPath = $file_path.'/'.$files;
    $rootPath = $files;
    $files2 = new RecursiveIteratorIterator(
      new RecursiveDirectoryIterator($files),
      RecursiveIteratorIterator::LEAVES_ONLY
    );
  //  print_r($files2); die;
    
    foreach ($files2 as $name => $file)
    {
  
    // Skip directories (they would be added automatically)
   
  
    if (!$file->isDir())
    {
    
        // Get real and relative path for current file
       $filePath = $file->getRealPath();
      // echo "<br/>";
        $relativePath = substr($filePath, strlen($rootPath) + 1);
    //echo "<br/>";
        // Add current file to archive
        
        $zip->addFile($filePath, $folder_name.$relativePath);
    }
}
}
if(is_file($files)){
  $file_name = basename($files);
$zip->addFile($files,$file_name);
}
}
    //==============================
      
      
     
  //  print_r($zip);die('----');
    $zip->close();
     }
     

  // ===================== ROHAN FUNCTION  ========================
  
  public function renamee(){
   // print_r($_REQUEST); die;
    $dirName = $_REQUEST['dir_name'];
    $fileName = $_REQUEST['file_name'];
    $firstName = $_REQUEST['first_name'];
    $newName = $_REQUEST['new_name'];
    $ext = $_REQUEST['extens'];
   // echo $firstName; die;
   //echo "$dirName.'/'.$fileName"; die;
    if(is_dir($dirName.'/'.$fileName)){
      rename($dirName.$fileName,$dirName.'/'.$newName);
    }else if($dirName !='' && $fileName !='' ){
    
     
     // echo $newName.'.'.$ext; die;
     if(rename($dirName.$fileName,$dirName.'/'.$newName.'.'.$ext)){
     // $this->UploadedFile->array
        echo "Renamed";
     }
     else{
       // print_r(error_get_last());
        echo "error in renaming";
     }

    }
    die;
  }



  public function movedir(){

      $sourcePath = $_REQUEST['dir_val'];
      $fileChecked = $_REQUEST['file_checked'];
      $destinationPath= $_REQUEST['desitnation_path'];

         //echo $sourcePath.$destinationPath;
         

   
      }


    public function permanentDelete(){

      $sourcePath = $_REQUEST['dir_val'];
      if(@$_REQUEST['data']!=''){
         $fileChecked = json_decode(stripslashes($_REQUEST['data']),true);
      }else{
         $fileChecked = $_REQUEST['file_checked'];
      }

     
      $destinationPath= $_REQUEST['desitnation_path'];
      

    foreach ( $fileChecked as $file ){
                if ($file != "." && $file != ".."){
                 
                    // $this->rcopy( "$sourcePath/$file", "$destinationPath/$file" );
                             
                    $this->rrmdir("$sourcePath/$file");
        
                  }
                }
                 $this->redirect('/discs/files');
      die;    
      }

     public function deleteSharedFile(){
     			
     	$file_checked = $_REQUEST['file_checked'];
     //	print_r($file_checked); die;
      $file_selected = $_REQUEST['file_selected'];
     
     $get_id = array();
  		 $i = 0;
  		 foreach ( $file_checked as $file ){
                if ($file != " "){
	$get_id[$i] = $this->ShareDocument->find('first',array('conditions' => array('ShareDocument.document_path' => $file_checked[$i])));

		if($get_id['ShareDocument']['id'] = $file_selected[$i]){
			// echo $file_checked[$i];
			// echo $file_selected[$i];

			 $this->rrmdir($file_checked[$i]);
			 $this->ShareDocument->delete($file_selected[$i]);
		}
		   
// print_r($get_id); die;
      
              //       $this->rrmdir("$file");
          				// $id = $file_selected[$i];
              //      $this->ShareDocument->delete($id);
                  }
                
 $i++;
                }
               
		   die;
               
    // foreach ( $file_selected as $id ){
    //             if ($id != " "){
                 
    //              $this->ShareDocument->delete($id);
        
    //               }
    //               $file = $file_checked[$i];
    //                $this->rrmdir("$file");
                 
    //             }

              //   $this->redirect('/discs/sharedpersons');
        

      }

// = ================ sharedTrash ================================

  public function sharedTrash(){

  //  print_r($_REQUEST); die;
    $TrashFiles = $_REQUEST['file_checked'];
  //  print_r($TrashFiles); die;
      foreach($TrashFiles as $file){
      $uploadFile = $this->UploadedFile->find('first',array('conditions',array('UploadedFile.file_path'=>$file)));
      //print_r($uploadFile); die;
      $upFileId = $uploadFile['UploadedFile']['id'];
      //echo $upFileId; die;
      $this->UploadedFile->delete($upFileId);

    $shareFile = $this->ShareDocument->find('all',array('conditions'=>array('ShareDocument.document_path'=> $file)));
    // print_r($shareFile); die;
     foreach ($shareFile as $ff) {
     $shareFileId = $ff['ShareDocument']['id'];
     $this->ShareDocument->delete($shareFileId);
      
     }


     $this->rrmdir($file);
      }
     
        $this->redirect('/discs/sharedpersons');
      
      }

// =========================================================

// ===================== TrashFile  ========================
      public function TrashFile(){

      $sourcePath = $_REQUEST['sourcepath'];
      $destinationPath = $_REQUEST['desitnation_path'];
      // $file_name = $_REQUEST['file_name'];
     
      $fileChecked = $_REQUEST['file_checked'];
  
      
      //$destinationPath= '/var/www/html/mybridge/app/webroot/disc_files/4/Trash/';

         // echo $sourcePath.$destinationPath;
         // print_r($fileChecked); die;

        foreach ( $fileChecked as $file ){    
                if ($file != "." && $file != ".."){
                 $file_type =  pathinfo($file, PATHINFO_EXTENSION);
               
                   $file_path =  $sourcePath.$file;
                //echo $file_path; die;
              
                $find_file = $this->ShareDocument->find('all',array('conditions'=>array('ShareDocument.document_path' => $file_path)));
                // print_r($find_file); die;
                foreach($find_file as $ff){
                 // print_r($ff); die;
                $this->ShareDocument->delete($ff['ShareDocument']['id']);  
                }

                $find_upload = $this->UploadedFile->find('first',array('conditions'=>array('UploadedFile.file_path'=>$file_path)));
                $this->UploadedFile->delete($find_upload['UploadedFile']['id']);

                    $this->rcopy( "$sourcePath/$file", "$destinationPath/$file" );
                             
                    $this->rrmdir("$sourcePath/$file");
            $store_files = array();
            $store_files['Mydiscfile']['name'] = $file;
            $store_files['Mydiscfile']['type'] = $file_type;
            $store_files['Mydiscfile']['trash_path'] = $destinationPath.$file;
            $store_files['Mydiscfile']['actual_path'] = $sourcePath;
                       
            $this->Mydiscfile->save($store_files);
            
            }
            $i++;
        }
        $this->Session->setFlash('Deleted successfully');
        $this->redirect('/discs/files');
      
      }


    public function copydir(){
      $sourcePath = $_REQUEST['dir_val'];
      $fileChecked = $_REQUEST['file_checked'];
      $destinationPath= $_REQUEST['desitnation_path'];

       foreach ( $fileChecked as $file ){
                if ($file != "." && $file != ".."){
                 
                $this->rcopy( "$sourcePath/$file", "$destinationPath/$file" );
               
                  }
                }
   die;

      }
   



    public function rcopy($sourcePath, $destinationPath) {
    // echo $sourcePath.'--'.$destinationPath; die;
       // echo $sourcePath.'====='.$destinationPath;
        // print_r($fileChecked);
      if($sourcePath == $destinationPath){
        $this->Session->setFlash('Copy is not possible to same directory');
        $this->redirect('/discs/files');
       }else{
           
            //rrmdir ( $destinationPath );
          if(is_dir($sourcePath.'/'.$file)){
           exec("cp -Rf $sourcePath/$file $destinationPath/$file");           
        
                    }
           // echo $sourcePath; die;
        if (is_dir ( $sourcePath )) {

           // mkdir ( $destinationPath );
            foreach ( $fileChecked as $file ){
                if ($file != "." && $file != ".."){
                    rcopy ( "$sourcePath/$file", "$destinationPath/$file" );     
                  }
                }
        } else if (file_exists ( $sourcePath )){
            copy ( $sourcePath, $destinationPath );
         
      }

        }
    }



     public function rrmdir($dir) {
      
      

                      if (is_dir($dir)) {
                         $it = new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS);
$files = new RecursiveIteratorIterator($it,
             RecursiveIteratorIterator::CHILD_FIRST);
foreach($files as $file) {
    if ($file->isDir()){
        rmdir($file->getRealPath());
    } else {
        unlink($file->getRealPath());
    }
}
rmdir($dir);        
                      }
                      else if(file_exists($dir)){
                     
                         unlink($dir);
                     }
                     
               
    }
    
//  public function copypopup(){
//     $dir = $_REQUEST['dir'];
//     $ffs = scandir($dir);
//    //echo count($ffs); die;
   
//     foreach($ffs as $ff){
//         if($ff != '.' && $ff != '..'){
//            if(is_dir($dir.'/'.$ff)){
//          //print_r(pathinfo("$ff",PATHINFO_BASENAME)); die;
//          $fol = "Folder-->";
//           echo '<tr ondblclick=javascript:show_files("'.$dir.'/'.$ff.'/") onclick=copy_file_popup("'.$dir.'/'.$ff.'")>';
//       echo '<td>'.$ff.'</td> <td><input type="checkbox" value='.$ff.' name="file_checked[]" class="select"/></td>';
//       echo '</tr>';
//          }
  
//         }
//     }
//   die; 
// }
public function copy(){
 ini_set('memory_limit', '512M');
        $this->layout='profile_page';
        $selected_items = [];
   //  print_r($_REQUEST); die;
        $selected_items = $_REQUEST['file_checked'];
        $dir_val = $_REQUEST['dir_val'];
        $this->set('selected_items',$selected_items); 
        $this->set('sourcepath',$dir_val);
   if(isset($_REQUEST['submit'])){
   // print_r($_REQUEST); die;
      $fileChecked = $_REQUEST['selected_values'];
      $destinationPath = $_REQUEST['copyspan'];
      $sourcePath = $_REQUEST['sourcepath'];
    // print_r($fileChecked); echo $sourcePath.'==='.$destinationPath; die;
       
     foreach ( $fileChecked as $file ){
                if ($file != "." && $file != ".."){
                   // $file = urlencode($file);
                    $this->rcopy( "$sourcePath$file","$destinationPath/$file" );
        
                  }
                }
                $this->Session->setFlash("Copied successfully");
      $this->redirect('/discs/files');
  
    
    
   }
}
public function copypopup(){
    $dir = $_REQUEST['dir'];
    
    $child = '';

    if(@$_REQUEST['child']){
      $child = $_REQUEST['child'];
    }
   echo $this->copyrecfiles($dir,$child);
  die; 
}

public function move(){
 ini_set('memory_limit', '512M');
        $this->layout='profile_page';
        $selected_items = [];
    //  print_r($_REQUEST); die;
        $selected_items = $_REQUEST['file_checked'];
        $dir_val = $_REQUEST['dir_val'];
        $this->set('selected_items',$selected_items); 
        $this->set('sourcepath',$dir_val);
   if(isset($_REQUEST['submit'])){
    //print_r($_REQUEST); die;
      $fileChecked = $_REQUEST['selected_values'];
      $destinationPath = $_REQUEST['movepath'];
      $sourcePath = $_REQUEST['sourcepath'];
   // echo $destinationPath; die;
       //  echo $sourcePath.'========='.$destinationPath; die;
       if($sourcePath == $destinationPath.'/'){
        $this->Session->setFlash('Move is not possible to same directory');
        $this->redirect('/discs/files');
       }else{
      
     foreach ( $fileChecked as $file ){
                if ($file != "." && $file != ".."){
                   $file = urlencode($file);
                 //  echo $destinationPath.'/'.$file; die;
                 // echo $file; die;
          $shareFile = $this->ShareDocument->find('all',array('conditions'=> array('ShareDocument.document_path' => $sourcePath.$file)));
          // print_r($shareFile); die;
          foreach($shareFile as $ff){
            $shareId = $ff['ShareDocument']['id'];
            
            $shareUpdate = array();
            $shareUpdate['ShareDocument']['id']= $shareId;
            $shareUpdate['ShareDocument']['document_path'] = $destinationPath.'/'.$file;
            $this->ShareDocument->save($shareUpdate);
          }

          $uploadFile = $this->UploadedFile->find('first',array('conditions'=> array('UploadedFile.file_path' => $sourcePath.$file)));
         
            $uploadId = $uploadFile['UploadedFile']['id'];
            //echo $uploadId;
            $uploadUpdate = array();
            $uploadUpdate['UploadedFile']['id']= $uploadId;
            $uploadUpdate['UploadedFile']['file_path'] = $destinationPath.'/'.$file;
            $this->UploadedFile->save($uploadUpdate);
      

           //die("end");
                    $this->rcopy( "$sourcePath$file","$destinationPath/$file" );
                             
                  $this->rrmdir("$sourcePath/$file");
        
                  }
                }
      $this->Session->setFlash("Moved successfully");
      $this->redirect('/discs/files');
  
    
     }
   }
}



public function movepopup(){
 
    $child = '';
  $dir = $_REQUEST['dir'];
    if(@$_REQUEST['child']){
      $child = $_REQUEST['child'];
    }
   echo $this->getrecfiles($dir,$child);
  die; 
}


// =================================================
 public function listFolderFiles($dir,$forAction){
    // echo $dir; die('--');
    $ffs = scandir($dir);
  // print_r($ffs); die;
    foreach($ffs as $ff){

        if($ff != '.' && $ff != '..'){
          $file_date = '--';
        $filee = $dir.$ff;
       // echo $filee; die;
        $modifiedData = $this->UploadedFile->find('first',array('conditions'=>array('UploadedFile.file_path' => $filee)));
        // print_r($modifiedData); die;
      $modified_date = $modifiedData['UploadedFile']['modified_at'];
      //echo $modified_date; die;
      
       $modified_date2 = date("m/d/Y h:i a", strtotime($modified_date));

      $modified_by = $modifiedData['UploadedFile']['modified_by'];
    if($modified_date == ''){
      $modified_date2 = '--';
    }else{
      $modified_date2 = date("m/d/Y h:i A", strtotime($modified_date));
    }

        
     $number = $this->ShareDocument->find('all',array('conditions'=>array('ShareDocument.document_path' => $filee)));
    // print_r(count($number)); die;
     if(count($number) == '0'){
      $count = '0';
     } else{
     $count  = count($number);
     }               
           if(is_dir($dir.'/'.$ff)){
            //if($ff != '.' && $ff != '..'){
           // echo $dir.$ff; die;
              $fol = "<img src=".BASE_URL."/images/tb1.png>";

             echo "<tr oncontextmenu=\"get_select_right_click(this);\" class=\"folderTr\" ondblclick=\"javascript:show_files('$dir$ff/')\" onclick=javascript:select_file(this)>";
              echo '<td>'.$fol.$ff.'</td> <td><input style="display:none;" type="checkbox" rel = '.$ff.' value="'.$ff.'" name="file_checked[]" class="select"/>'.$modified_date2.' '.$modified_by.'</td><td style="text-align:left !important;">';
              if($count != 0){ echo '<span class="count1r">' .($count - 1).'</span>';
              } else{ echo '--';}
                echo '</td><td><a href="'.BASE_URL.'discs/share?path='.$dir.$ff.'"><button type="button" style="float:right;" >Share </button></a></td>';
              echo '</tr>';  
            //}
         }
         else{
             // echo $file_ext; die;
             $file_ext = pathinfo($ff, PATHINFO_EXTENSION);
             switch($file_ext){
              case "jpeg":
               $file = "<img src=".BASE_URL."/images/jpgdd.png>";
               break;
                case "gif":
               $file = "<img src=".BASE_URL."/images/jpgdd.png>";
               break;
                case "png":
               $file = "<img src=".BASE_URL."/images/jpgdd.png>";
               break;
               case "jpg":
               $file = "<img src=".BASE_URL."/images/jpgdd.png>";
               break;
               case "pdf":
               $file = "<img src=".BASE_URL."/images/gsw.png>";
               break;
               case "ctp":
               $file = "<img src=".BASE_URL."/images/doc.png>";
               break;
                case "html":
               $file = "<img src=".BASE_URL."/images/ord.png>";
               break;
               case "xls":
               $file = "<img src=".BASE_URL."/images/sf.png>";
               break;
               case "docx":
               $file = "<img src=".BASE_URL."/images/ub.png>";
               break;
               case "ppt":
               $file = "<img src=".BASE_URL."/images/prsn.png>";
               break;
               case "zip":
               $file = "<img src=".BASE_URL."/images/mdc.png>";
               break;
               case "gz":
               $file = "<img src=".BASE_URL."/images/mdc.png>";
               break;
               case "tar":
               $file = "<img src=".BASE_URL."/images/mdc.png>";
               break;
               default:
               $file = "<img src=".BASE_URL."/images/at1.png>";
               break;

             }



               $fol = "";
                      echo '<tr oncontextmenu="get_select_right_click(this); return false;" class="folderTr" ondblclick="download_files_selected(this)" onclick=javascript:select_file(this)>';
                      echo '<td >'.$file.$ff.'</td><td><input style="display:none;" type="checkbox" rel = '.$ff.' value="'.$ff.'" name="file_checked[]" id='.$dir.$ff.' class="select"/>'.$modified_date2.' '.$modified_by.'</td><td style="text-align:left !important;">';
                      if($count != 0){ echo '<span class="count1r">'.($count - 1).'</span>';
                    } else{ echo '--';}
                      echo  '</td><td><a href="'.BASE_URL.'discs/share?path='.$dir.$ff.'"><button type="button" style="float:right;">Share </button></a></td>';
                      echo '</tr>'; 
          }     
        }
    }
    $sizeffs = sizeof($ffs);
    if($sizeffs == 2){
                           

    }
   
}

//===================================================

  public function getrestorefile(){
     $src_file = $_REQUEST['src_path'];

    // GET destination path QUERY
     $get_dest = $this->Mydiscfile->find('first', array(
        'conditions' => array('Mydiscfile.trash_path' => $src_file)
    ));
    
     $get_dest_path = $get_dest['Mydiscfile']['actual_path'];
     $get_dest_name = $get_dest['Mydiscfile']['name'];

   // echo $get_dest_path; die;

     $this->rcopy( $src_file, $get_dest_path.'/'.$get_dest_name );
                             
                  $this->rrmdir($src_file);
die;
  }
  

//=================trash listing====================
// =================================================
 public function listFolderFilesTrash($dir,$forAction){
    // echo $dir; die('--');
    $ffs = scandir($dir);
 
    foreach($ffs as $ff){

        if($ff != '.' && $ff != '..'){
      $file_date = filemtime($dir.'/'.$ff);
      $file_date = gmdate("m/d/Y H:i:s", $file_date);

              //echo   $dir.'/'.$ff;die;         
           if(is_dir($dir.'/'.$ff)){
                 $fol = "<img src=".BASE_URL."/images/tb1.png>";
            //if($ff != '.' && $ff != '..'){                              
              echo "<tr class=\"folderTr\" ondblclick=\"javascript:show_files('$dir/$ff/')\" onclick=javascript:select_file(this)>";
              echo '<td>'.$fol.$ff.'</td> <td><input style="display:none;" type="checkbox" rel = '.$ff.' value="'.$ff.'" name="file_checked[]" class="select"/>'.$file_date.'</td>';
              echo "<td><a  href=\"javascript:void(0);\"><button type=\"button\"  onclick=\"permanent_delete('$dir','$ff',this)\">Delete</button></a><a href=\"javascript:void(0);\"><button type=\"button\" onclick=\"restore_file('$dir$ff')\">Restore</button></a></td>";
              echo '</tr>'; 
            //}
         }
         else{
             $file_ext = pathinfo($ff, PATHINFO_EXTENSION);
             // echo $file_ext; die;
             switch($file_ext){
              case "jpeg":
               $file = "<img src=".BASE_URL."/images/jpgdd.png>";
               break;
                case "gif":
               $file = "<img src=".BASE_URL."/images/jpgdd.png>";
               break;
                case "png":
               $file = "<img src=".BASE_URL."/images/jpgdd.png>";
               break;
               case "jpg":
               $file = "<img src=".BASE_URL."/images/jpgdd.png>";
               break;
               case "pdf":
               $file = "<img src=".BASE_URL."/images/gsw.png>";
               break;
               case "ctp":
               $file = "<img src=".BASE_URL."/images/doc.png>";
               break;
                case "html":
               $file = "<img src=".BASE_URL."/images/ord.png>";
               break;
               case "xls":
               $file = "<img src=".BASE_URL."/images/sf.png>";
               break;
               case "docx":
               $file = "<img src=".BASE_URL."/images/ub.png>";
               break;
               case "ppt":
               $file = "<img src=".BASE_URL."/images/prsn.png>";
               break;
               case "zip":
               $file = "<img src=".BASE_URL."/images/mdc.png>";
               break;
               case "gz":
               $file = "<img src=".BASE_URL."/images/mdc.png>";
               break;
               case "tar":
               $file = "<img src=".BASE_URL."/images/mdc.png>";
               break;
               case "mp3":
               $file = "<img src=".BASE_URL."/images/music-player.png>";
               break;
               case "wav":
               $file = "<img src=".BASE_URL."/images/music-player.png>";
               break;
               default:
               $file = "<img src=".BASE_URL."/images/at1.png>";
               break;

             }



               $fol = "";
                      echo '<tr class="folderTr" onclick=javascript:select_file(this)>';
                      echo '<td>'.$file.$ff.'</td><td><input style="display:none;" type="checkbox" rel = '.$ff.' value="'.$ff.'" name="file_checked[]" id='.$dir.$ff.' class="select"/>'.$file_date.'</td>';
                      echo "<td><a  href=\"javascript:void(0);\"><button type=\"button\"   onclick=\"permanent_delete('$dir','$ff',this)\">Delete</button></a><a href=\"javascript:void(0);\"><button type=\"button\" onclick=\"restore_file('$dir$ff')\">Restore</button></a></td>";
                      echo '</tr>'; 
          }
 
           // if(is_dir($dir.'/'.$ff)) $this->listFolderFiles($dir.'/'.$ff);
            
        }
    }
      $sizeffs = sizeof($ffs);

    if($sizeffs == 2){
                           

    }
   
}

// ==================================================

 public function showfilesrecursive($user_id){
  $user_id = 4;
  //ECHO DOCUMENT_ROOT_DISC; die;
   
  // echo count($ffs); die;
  $dir =  DOCUMENT_ROOT_DISC.$user_id;
   echo $this->getrecfilesmo($dir);
    die;    

           
        
        
            
           // if(is_dir($dir.'/'.$ff)) $this->listFolderFiles($dir.'/'.$ff);
            
        }
        
      
       
 public function getrecfiles($dir,$child){
            
      
            $ffs = scandir($dir);
            
            $folderImg = 'sidm1.png';

            if(@$child=='child'){
              
              $folderImg = 'ordinairy.png';
            }else{
              echo '<ul class="accordion" id="moveAccordian">';
            }

            
            foreach($ffs as $ff){

              if($ff != '.' && $ff != '..'){
                 
                  if(is_dir($dir.'/'.$ff)){

                        if($ff=='Trash'){
                          continue;
                        }
                            switch($ff)
                        {
                          case 'Documents':$folderImg = 'docm.png';break;
                          case 'Music':$folderImg = 'music.png';break;
                          case 'Pictures':$folderImg = 'picture.png';break;
                          case 'Videos':$folderImg = 'video.png';break;
                        }

                        echo '<li data-dir="'.$dir.'/'.$ff.'" >
                                    <div class="link" >
                                    <img src="'.BASE_URL.'/images/'. $folderImg.'">
                                    <span>'.$ff.' </span>
                                    <i class="i_1 glyphicon glyphicon-plus folderList" 
                                    onclick=select_file_popup("'.$dir.'/'.$ff.'",this)>
                                    </i>
                                    </div>
                                    <ul class="submenu" style="display:block;"></ul>
                                </li>';
                                
                               
                        /*echo '<div class="panel panel-default movedeafult">
                                  <div class="moveheading panel-heading">
                                       <h4 class="panel-title">
                                          <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#panel1">
                                          <i class="glyphicon glyphicon-minus"></i> <img src="../images/music.png"> '.$ff.'</a>
                                      </h4>

                                  </div>
                                 
                              </div>';*/
                        //echo '<li onclick=select_file_popup("'.$dir.'/'.$ff.'")>';
                        //echo $ff;
                        //echo '</li>'; 
                  }
                    
                    /*if(is_dir($dir.'/'.$ff)) 
                    {
                        $this->getrecfiles($dir.'/'.$ff);
                    }*/
                }
            }
            echo '</ul>';
      }



      // get folder and subfolder for copy function
      public function getcopyfiles($dir,$child){
            
      
            $ffs = scandir($dir);
            
            $folderImg = 'sidm1.png';

            if(@$child=='child'){
              
              $folderImg = 'ordinairy.png';
            }else{
              echo '<ul class="accordion" id="moveAccordian">';
            }

            
            foreach($ffs as $ff){

              if($ff != '.' && $ff != '..'){
                 
                  if(is_dir($dir.'/'.$ff)){

                        if($ff=='Trash'){
                          continue;
                        }
                            switch($ff)
                        {
                          case 'Documents':$folderImg = 'docm.png';break;
                          case 'Music':$folderImg = 'music.png';break;
                          case 'Pictures':$folderImg = 'picture.png';break;
                          case 'Videos':$folderImg = 'video.png';break;
                        }

                        echo '<li data-dir="'.$dir.'/'.$ff.'" >
                                    <div class="link" >
                                    <img src="'.BASE_URL.'/images/'. $folderImg.'">
                                    <span>'.$ff.' </span>
                                    <i class="i_1 glyphicon glyphicon-plus folderListCopy" 
                                    onclick=copy_file_popup("'.$dir.'/'.$ff.'",this)>
                                    </i>
                                    </div>
                                    <ul class="submenu" style="display:block;"></ul>
                                </li>';
                                
                               
                        /*echo '<div class="panel panel-default movedeafult">
                                  <div class="moveheading panel-heading">
                                       <h4 class="panel-title">
                                          <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#panel1">
                                          <i class="glyphicon glyphicon-minus"></i> <img src="../images/music.png"> '.$ff.'</a>
                                      </h4>

                                  </div>
                                 
                              </div>';*/
                        //echo '<li onclick=select_file_popup("'.$dir.'/'.$ff.'")>';
                        //echo $ff;
                        //echo '</li>'; 
                  }
                    
                    /*if(is_dir($dir.'/'.$ff)) 
                    {
                        $this->getrecfiles($dir.'/'.$ff);
                    }*/
                }
            }
            echo '</ul>';
      }
    
   
   

   public function copyrecfiles($dir,$child){
            
      
            $ffs = scandir($dir);
            
            $folderImg = 'sidm1.png';

            if(@$child=='child'){
              
              $folderImg = 'ordinairy.png';
            }else{
              echo '<ul class="accordion" id="moveAccordian">';
            }

            
            foreach($ffs as $ff){

              if($ff != '.' && $ff != '..'){
                 
                  if(is_dir($dir.'/'.$ff)){

                        if($ff=='Trash'){
                          continue;
                        }
                            switch($ff)
                        {
                          case 'Documents':$folderImg = 'docm.png';break;
                          case 'Music':$folderImg = 'music.png';break;
                          case 'Pictures':$folderImg = 'picture.png';break;
                          case 'Videos':$folderImg = 'video.png';break;
                        }

                       echo '<li data-dir="'.$dir.'/'.$ff.'" >
                                    <div class="link" >
                                    <img src="'.BASE_URL.'/images/'. $folderImg.'">
                                    <span>'.$ff.' </span>
                                    <i class="i_1 glyphicon glyphicon-plus folderListCopy" onclick=copy_file_popup("'.$dir.'/'.$ff.'",this) id="plusicon"></i>
                                    </div>
                                    <ul class="submenu" style="display:block;"></ul>
                                </li>';

                                                    
                                
                               
                        /*echo '<div class="panel panel-default movedeafult">
                                  <div class="moveheading panel-heading">
                                       <h4 class="panel-title">
                                          <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#panel1">
                                          <i class="glyphicon glyphicon-minus"></i> <img src="../images/music.png"> '.$ff.'</a>
                                      </h4>

                                  </div>
                                 
                              </div>';*/
                        //echo '<li onclick=select_file_popup("'.$dir.'/'.$ff.'")>';
                        //echo $ff;
                        //echo '</li>'; 
                  }
                    
                    /*if(is_dir($dir.'/'.$ff)) 
                    {
                        $this->getrecfiles($dir.'/'.$ff);
                    }*/
                }
            }
            echo '</ul>';
      }

    
    
  function changepermission(){

    if(isset($_REQUEST['shared_doc_id'])){

      $shared_doc_id = $_REQUEST['shared_doc_id'];
      $shared_doc_perm = $_REQUEST['shared_doc_perm'];
   

      $shared_doc = array();
      $shared_doc['ShareDocument']['users_permission'] = $shared_doc_perm;
      $shared_doc['ShareDocument']['id'] = $shared_doc_id;
      $this->ShareDocument->save($shared_doc);
      
    }
    die;
  }
  function deleteshareduser(){
     if(isset($_REQUEST['shared_doc_id'])){
      $shared_doc_id = $_REQUEST['shared_doc_id'];
      if($this->ShareDocument->delete($shared_doc_id)){
        echo "success";
      }
     }
     die;
  }
  
  // ================ SHARED PERSONS LISTING  ===================
  
  function sharedpersons(){
	$this->layout='profile_page';
	$loginUserId=USERID; 
    $permissionData=$this->ShareDocument->find('all', array('conditions' => array('ShareDocument.share_with_users_id  '=> $loginUserId)));
	

  //print_r($permissionData); die;








  //echo "<pre>"; print_r($permissionData);die;
      /*
  $nameIdArr=array();
    foreach($permissionData as $key=>$permission){
        if($key == 0){
          $nameIdArr[]=$permission['ShareDocument']['user_id'];
          $permission['ShareDocument']['first_name']=$permission['Profile']['first_name'];
          $permission['ShareDocument']['last_name']=$permission['Profile']['last_name'];
          $permission['ShareDocument']['image_url']=$permission['User']['image_url'];
          $PermissionUserArr[]=$permission['ShareDocument'];
        }
        if(!in_array($permission['ShareDocument']['user_id'],$nameIdArr)) {

        $permission['ShareDocument']['first_name']=$permission['Profile']['first_name'];
        $permission['ShareDocument']['last_name']=$permission['Profile']['last_name'];
        $permission['ShareDocument']['image_url']=$permission['User']['image_url'];
        $PermissionUserArr[]=$permission['ShareDocument'];
        $nameIdArr[]=$permission['ShareDocument']['user_id'];
      }
      */
        //$this->set('shareFile',$shareFile);
$profileData = array();
$i=0;
  foreach($permissionData as $share=>$k){
   // print_r($permissionData['user_id']); die;
      $shareId=$k['ShareDocument']['user_id'];

      $profileData[$i]['user_id'] = $k['Profile']['user_id'];
      $profileData[$i]['first_name'] = $k['Profile']['first_name'];
      $profileData[$i]['last_name'] = $k['Profile']['last_name'];
      $profileData[$i]['image_url'] = $k['Profile']['image_url'];
      $profileData[$i]['permissions'] = $k['ShareDocument']['users_permission'];
      $profileData[$i]['shared_doc_id'] = $k['ShareDocument']['id'];
$i++;
  }
     // print_r($profileData); die;
    $this->set('PermissionUserArr2',$profileData);

    }

 public function listFolderFilesShared($dir,$permission_nm){
    // echo $dir; die('--');
    $ffs = scandir($dir);
    $perm_rel = $permission_nm;
    $permission_name = $permission_nm;

    if($permission_name == 'write'){
      $permission_name = 'Can Write';
    }
    else{
      $permission_name = 'Can View';

    }
  // print_r($ffs); die;
    foreach($ffs as $ff){

        if($ff != '.' && $ff != '..'){
      $file_date = filemtime($dir.'/'.$ff);
      $file_date = gmdate("m/d/Y h:i a", $file_date);

                         
           if(is_dir($dir.'/'.$ff)){
            //if($ff != '.' && $ff != '..'){
              $fol = "<img src=".BASE_URL."/images/tb1.png>";

              echo "<tr class=\"folderTr\" ondblclick=\"javascript:show_files('$dir/$ff/')\" onclick=javascript:select_file(this)>";
              echo '<td>'.$fol.$ff.'</td> <td><input style="display:none;" type="checkbox" rel = '.$perm_rel.' value="'.$ff.'" name="file_checked[]" class="select"/></td><td></td><td><a href="'.BASE_URL.'discs/share?path='.$dir.$ff.'"><button type="button" style="float:right !important;">Share </button></a></td>';
              echo '</tr>';
            //}
         }
         else{
             // echo $file_ext; die;
             $file_ext = pathinfo($ff, PATHINFO_EXTENSION);
             switch($file_ext){
              case "jpeg":
               $file = "<img src=".BASE_URL."/images/jpgdd.png>";
               break;
                case "gif":
               $file = "<img src=".BASE_URL."/images/jpgdd.png>";
               break;
                case "png":
               $file = "<img src=".BASE_URL."/images/jpgdd.png>";
               break;
               case "jpg":
               $file = "<img src=".BASE_URL."/images/jpgdd.png>";
               break;
               case "pdf":
               $file = "<img src=".BASE_URL."/images/gsw.png>";
               break;
               case "ctp":
               $file = "<img src=".BASE_URL."/images/doc.png>";
               break;
                case "html":
               $file = "<img src=".BASE_URL."/images/ord.png>";
               break;
               case "xls":
               $file = "<img src=".BASE_URL."/images/sf.png>";
               break;
               case "docx":
               $file = "<img src=".BASE_URL."/images/ub.png>";
               break;
               case "ppt":
               $file = "<img src=".BASE_URL."/images/prsn.png>";
               break;
               case "zip":
               $file = "<img src=".BASE_URL."/images/mdc.png>";
               break;
               case "gz":
               $file = "<img src=".BASE_URL."/images/mdc.png>";
               break;
               case "tar":
               $file = "<img src=".BASE_URL."/images/mdc.png>";
               break;
               default:
               $file = "<img src=".BASE_URL."/images/at1.png>";
               break;

             }



               $fol = "";
                      echo '<tr class="folderTr" onclick=javascript:select_file(this)>';
                      echo '<td>'.$file.$ff.'</td><td><input style="display:none;" type="checkbox" rel = '.$perm_rel.' value="'.$ff.'" name="file_checked[]" id='.$dir.$ff.' class="select"/></td><td><a href="'.BASE_URL.'discs/share?path='.$dir.$ff.'"><td></td><button type="button" style="float:right !important;">Share </button></a></td>';
                      echo '</tr>';
          }
           
        
        
            
           // if(is_dir($dir.'/'.$ff)) $this->listFolderFiles($dir.'/'.$ff);
            
        }
    }
    $sizeffs = sizeof($ffs);
    if($sizeffs == 2){
                           

    }
   
}


// ============== GET FILE FOR SHARED (VISHAL - 29-08-2016 ) ====================
    public function getfilesshared() {
     if(isset($_REQUEST['dir_path']) && $_REQUEST['dir_path'] != ''){
      //echo $_REQUEST['dir_path']; die;
      $dir_path = $_REQUEST['dir_path'];
      echo '<tr><th>Name</th><th>Modified</th><th style="width:8px;"></th><th>Share With</th><tr>';
   //   $permission_type = $_REQUEST['permission_nm'];
      $this->listFolderFilesShared($dir_path);
    }

    die;
    }
//========================= 

  }



