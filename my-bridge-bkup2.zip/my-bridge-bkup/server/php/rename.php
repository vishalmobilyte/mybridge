<?php
$newName = $_REQUEST['New_name'];
$dirpath = $_REQUEST['dir_path'];


rename("/var/www/html/uploads/public/rename.php", "/var/www/html/uploads/public/rename.txt");

?>