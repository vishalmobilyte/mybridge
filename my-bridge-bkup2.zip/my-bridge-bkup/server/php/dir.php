<?php
 $fname = $_REQUEST['folder_name'];
 $dirpath = $_REQUEST['dir_path'];

makedirs($dirpath,$fname);
 function makedirs($dirpath,$fname) {
     $dirp =  $dirpath;

      $filename =  $fname;  
     
    //   echo $dirp.'/'.$filename; die;
     mkdir($dirp.'/'.$filename);
     chmod($dirp.'/'.$filename, 0777);
}

?>
    